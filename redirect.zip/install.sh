sudo mkdir /nemo/ & sudo cp ./med.py /usr/bin/ & sudo chmod +x /usr/bin/med.py & sudo cp ./ipgeo.py /nemo/
